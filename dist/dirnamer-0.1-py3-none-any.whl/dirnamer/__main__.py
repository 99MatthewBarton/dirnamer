from .dirnamer import main

main()
